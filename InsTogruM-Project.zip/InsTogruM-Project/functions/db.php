<?php 

$conn = mysqli_connect('localhost', 'root', '', 'instogrum_web' );

?>